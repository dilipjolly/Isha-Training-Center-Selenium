import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains as AC


driver = webdriver.Chrome()
driver.maximize_window()

driver.get(r"D:/Isha/SeleniumPythonClass/StaticWebPage/site-1/index.html")
time.sleep(2.5)

table_element = driver.find_element(By.XPATH,"//h2[text()='Image']")
AC(driver).scroll_to_element(table_element).perform()

time.sleep(2.5)

#task-1 (how many rows in this table)
row_elements = driver.find_elements(By.XPATH,"//table//tr")       #0,1,2,3,4,5
print("Number of table rows: {}".format(len(row_elements)))
#task-2 (how many rows in this table - excluding table headers)
print("Number of table rows except headers row: {}".format(len(row_elements)-1))

###task-3 (print the table headers data)
##Approach1
# table_headers = driver.find_elements(By.XPATH,"//table//tr[1]/th")
# for header in table_headers:
#     value = header.text
#     print(value)
##Approach2
# header_row = row_elements[0]
# table_headers = header_row.find_elements(By.XPATH,"./th")
# for header in table_headers:
#     value = header.text
#     print(value)

##task-4 (print all the row data)
#1,2,3,4,5

# for i in range(1,len(row_elements)):
#     data_elements = row_elements[i].find_elements(By.XPATH,"./td")
#     for data in data_elements:
#         print(data.text,end=" ")        #end operator gives space in space line
#     print("")     #goes to new line in console

#task5 (print the age & country of Sachin)
#//table//tr/td
for i in range(1,len(row_elements)):
    row_data_elements = row_elements[i].find_elements(By.XPATH,"./td")
    Name = row_data_elements[0].text
    if Name == "Sachin":
        print("Age is {}".format(row_data_elements[1].text))
        print("Country is {}".format(row_data_elements[2].text))
        break

#task6: print the person names belong to country USA
#task7: print the person names who is having age greater than 25



