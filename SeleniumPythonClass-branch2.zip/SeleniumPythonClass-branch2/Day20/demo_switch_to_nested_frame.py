import time

from selenium import webdriver
from selenium.webdriver.common.by import By


class Demo_iframe:
    def testcase(self):
        browser = webdriver.Chrome()
        browser.maximize_window()

        url = "https://demo.automationtesting.in/Frames.html"
        browser.get(url)
        time.sleep(2.5)

        ### Click on Nested frame Section

        browser.find_element(By.PARTIAL_LINK_TEXT,"Iframe with in an Iframe").click()
        time.sleep(3)

        input_field_xpath = "//input[@type='text']"
        #####################################################
        ## switch to 1st frame
        frame_element = browser.find_element(By.XPATH, "//iframe[@src='MultipleFrames.html']")
        browser.switch_to.frame(frame_element)
        ## switch to 2nd frame
        frame_element = browser.find_element(By.XPATH, "//iframe[@src='SingleFrame.html']")
        browser.switch_to.frame(frame_element)
        #####################################################

        webelement = browser.find_element(By.XPATH,input_field_xpath)

        webelement.send_keys("Isha")

        time.sleep(5)


obj = Demo_iframe()
obj.testcase()


