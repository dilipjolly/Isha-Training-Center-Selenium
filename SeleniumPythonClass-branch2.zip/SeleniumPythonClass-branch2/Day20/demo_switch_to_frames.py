import time

from selenium import webdriver
from selenium.webdriver.common.by import By


class Demo_iframe:
    def testcase(self):
        browser = webdriver.Chrome()
        browser.maximize_window()

        url = "https://demo.automationtesting.in/Frames.html"
        browser.get(url)
        time.sleep(2.5)

        input_filed_xpath = "//input[@type='text']"
        #####################################################
        ## switch to frame
        #browser.switch_to.frame("singleframe")     # way-1
        # way-2
        # frame_element = browser.find_element(By.ID,"singleframe")
        frame_element = browser.find_element(By.XPATH, "//iframe[@src='SingleFrame.html']")
        browser.switch_to.frame(frame_element)
        #####################################################

        browser.find_element(By.XPATH,input_filed_xpath).send_keys("Isha")

        time.sleep(5)

        browser.switch_to.default_content()
        browser.find_element(By.PARTIAL_LINK_TEXT,"Register").click()

        time.sleep(5)


obj = Demo_iframe()
obj.testcase()


