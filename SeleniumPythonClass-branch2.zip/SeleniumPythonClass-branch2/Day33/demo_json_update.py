import json
# import jsonpath_ng  #pip install jsonpath-ng
from jsonpath_ng import parse

#reading json data from the file
obj = open("D:\Isha\SeleniumPythonClass\Day32\Logs\sample1.json","r")
data = obj.read()
obj.close()

l = json.loads(data)

#method1
# l[0]["country"] = "AFRICA"
# json_string = json.dumps(l,indent=4)

#method2
parse("$[0].name").update(l,"Dhoni")
json_string = json.dumps(l,indent=4)

#update json data from the file
obj = open("D:\Isha\SeleniumPythonClass\Day32\Logs\sample1.json","w+")
obj.write(json_string)
obj.close()

