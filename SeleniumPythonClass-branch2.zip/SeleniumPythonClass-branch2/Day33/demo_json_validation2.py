import json
# import jsonpath_ng  #pip install jsonpath-ng
from jsonpath_ng import parse

#reading json data from the file
obj = open("D:\Isha\SeleniumPythonClass\Day32\Logs\sample1.json","r")
data = obj.read()
obj.close()

l = json.loads(data)

#method1
test_wkts = l[0]["country"]["TEST"]
print(test_wkts)
#method2
obj1 = parse("$.[0].wickets_taken.TEST").find(l)
print(obj1[0].value)

try:
    obj1 = parse("$.[0].wickets_taken.TEST20").find(l)
    print(obj1[0].value)
except:
    print("TEST20 is not present")
finally:
    pass






