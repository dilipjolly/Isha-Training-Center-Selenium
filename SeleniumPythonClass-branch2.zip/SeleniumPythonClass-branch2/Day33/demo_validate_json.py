import json

#reading json data from the file
obj = open("D:\Isha\SeleniumPythonClass\Day32\Logs\sample.json","r")
data = obj.read()
obj.close()


py_obj = json.loads(data)       # string dt to python obj
print(type(py_obj))


for obj in py_obj:
    pass
    # print(obj.get("name"))
    # print(obj["name"])

# Task1 - do we have a bowler who took more than 500 wkts

for obj in py_obj:
    #wkts of each object
    wkts = obj.get("wickets_taken")
    #condition
    if wkts>=500:
        bowler = obj.get("name")
        print(bowler)



