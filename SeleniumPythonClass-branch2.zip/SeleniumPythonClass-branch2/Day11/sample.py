from Day11 import demo_module as dm
from Day11 import demo_bank
from Day11.demo_bank import Bank,Bank2

# dm.sub(5,55)

virat = Bank(12345678,"Virat Kohli","INDIA",30)
# virat.check_balance()
# print(virat.name)
# Bank2()