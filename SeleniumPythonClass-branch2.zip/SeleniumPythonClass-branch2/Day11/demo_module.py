def sub(a:int,b:int):
    print(a,b)
    print("HI, I am the function present in module")