class Mail:
    def __init__(self,id,name):
        self.id = id
        self.name = name

    def read_mail(self):
        pass

    def draft_mail(self):
        pass
    
    def send_mail(self):
        pass