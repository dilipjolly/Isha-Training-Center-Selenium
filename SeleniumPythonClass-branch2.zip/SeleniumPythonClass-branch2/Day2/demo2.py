#This is single line comment

'''This
is
Multi line
comment'''

# print("Hello World!")

# name = input("Please Enter your Name:")  # this store in string data type
# print(name)
# rool_num = int(input("Enter ur num"))
# print(rool_num)
# marks = (input("Enter ur total marks"))
# print(marks)

a,b = input("Enter Name & Age:").split(" ")
print(type(b))
b = int(b)
print(type(b))
print(a,b)

# var2 = input("Enter your age")  # str data type
# # convert var2 to int data type (Using type cast)
# age = int(var2)
# print(age)
# # know the data - type (type())
# print(type(var2))
# print(type(age))

# multiple inputs from user  ()
# x= input("give 5 inputs followed by any $ separator")
# print(x)
# l = x.split("$")
# print(l)

# a,b,c = input("Give 3 inputs by giving space as separator:").split(" ")
#
# print(a,b,c)


# print("My Name is Isha",end="    ")        #sep,end
# print("Hi")

# a=20
#global keyword
def function():
    global a
    a= 10  #local variable
    print(a)

# function()
# print(a)
# free up the memory - space (del)
# del(a)
# print(a)


# a= 100
# b=200
# print(a,b)
# # a=200 , b=100
# a,b = b,a
# print(a,b)

name = "Sachin Tendulkar"
#len(obj)
# char_length = len(name)
# print(char_length)

# print(len(name))






