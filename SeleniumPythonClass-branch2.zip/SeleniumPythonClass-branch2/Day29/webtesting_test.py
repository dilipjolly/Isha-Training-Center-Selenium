import time
import pytest

@pytest.mark.regression
def test_login():
    print(5-10)
    # time.sleep(2)
    assert True

@pytest.mark.regression
def test_logout():
    print(5+10)
    # time.sleep(2)
    assert True

@pytest.mark.sanity
@pytest.mark.regression
def test_add1():
    print(5+10)
    # time.sleep(2)
    assert True

@pytest.mark.smoke
def test_multiply():
    print(10*5)
    assert True