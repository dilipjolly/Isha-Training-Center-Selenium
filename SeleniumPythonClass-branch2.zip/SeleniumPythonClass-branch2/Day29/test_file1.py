import time
import pytest

class Test_Class1:

    @pytest.fixture()
    def function1(self):
        return "Hi"

    @pytest.mark.regression
    def test_subtract(self,function1):
        print(function1)
        print(5-10)
        # time.sleep(2)
        assert True


    @pytest.mark.regression
    def test_add(self):
        print(5+10)
        # time.sleep(2)
        assert False,"There is a failure"

    @pytest.mark.sanity
    @pytest.mark.regression
    def test_add1(self):
        print(5+10)
        # time.sleep(2)
        assert False

    @pytest.mark.smoke
    @pytest.mark.skip
    def test_multiply(self):
        print(10*5)

    @pytest.mark.parametrize("a,b,expected_value",[(10,2,5),(100,5,21),(21,7,3.0)])
    def test_division(self,a,b,expected_value):
        result = a//b
        print(result,expected_value)
        assert result==expected_value

