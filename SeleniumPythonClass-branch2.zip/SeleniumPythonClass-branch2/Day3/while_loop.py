variable = 1
#1,2,3

while(variable<11):
    print(variable)
    variable = variable +1

    # variable = variable+1