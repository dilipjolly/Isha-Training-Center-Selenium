# mlc - elections
# main elections

def fn():
    age = 18
    degree = True

    if age>=18:
        print("Eligible to vote for main elections.")
    if age>=18 and degree ==True:
        print("Eligible to vote for MLC elections.")
    else:
        print("Not eligible.")
        print("Not eligible.")

    print("My code finished.")

age = 17
citizen = "Asian"

if age >=18 :
    if citizen == "Indian":
        print("Vote eligible for Indian.")
    else:
        print("He/She is not an Indian")
else:
    print("Not eligible.")
