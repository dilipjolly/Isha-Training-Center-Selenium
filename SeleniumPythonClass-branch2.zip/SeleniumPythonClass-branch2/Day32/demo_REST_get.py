import requests
import json

end_point_url = "http://localhost:8000/api/bowlers/"

##with auth
# response = requests.get(url=end_point_url,auth=("admin","admin"))
#without auth
response = requests.get(url=end_point_url)

print(response)
data = response.text
print(data)        #string

obj = open("D:\Isha\SeleniumPythonClass\Day32\Logs\sample.json","w+")

json_obj = json.loads(response.text)        #string which is in json format to python dict dt

json_data = json.dumps(json_obj,indent=4)        # python dict to string which is in json format

obj.write(json_data)
obj.close()

