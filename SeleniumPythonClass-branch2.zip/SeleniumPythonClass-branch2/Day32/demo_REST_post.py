import requests

url = "http://localhost:8000/api/bowlers/"
data= {
        "name": "Bumrah",
        "age": 31,
        "country": "INDIA",
        "wickets_taken": 500,
        "bowling_average": 100.0,
        "bowling_strikerate": 50.0,
        "economy_rate": 8.33
    }

response = requests.post(url,json=data,auth=('admin','admin'))

print(response)
print("Done.")