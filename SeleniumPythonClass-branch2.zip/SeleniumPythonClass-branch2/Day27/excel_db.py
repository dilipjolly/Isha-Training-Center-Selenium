import pyodbc
print(pyodbc.drivers())

#excel Server / DB Server
excel_driver = "Microsoft Excel Driver (*.xls, *.xlsx, *.xlsm, *.xlsb)"

#Excel workbook / database
excel_filepath = "D:\Isha\SeleniumPythonClass\ExternalFiles\DataSheet.xlsx"

#Connection string
conn_string = "Driver={"+excel_driver+"};DBQ="+excel_filepath+";ReadOnly=True"

conn = pyodbc.connect(conn_string,autocommit=True)
print("Connection established.")
cursor = conn.cursor()

#CRUD
def retrieve_data():
    query = "SELECT COUNT(*) FROM [EMPLOYEES$] "  # select * from [table_name$]
    cursor.execute(query)

    records = cursor.fetchall()
    print(cursor.description)
    print(records)


def update_data():
    query = "UPDATE [EMPLOYEES$] SET COUNTRY='SRI LANKA' WHERE NAME = 'Sehwag'"        # update table_name set col_name = 'value'
    cursor.execute(query)
    cursor.commit()
    print("data updated.")

def delete_record():
    sql_query = "DELETE FROM [EMPLOYEES$] WHERE NAME = 'Sachin'"
    cursor.execute(sql_query)
    cursor.commit()
    print("row data deleted.")
    ##pyodbc.Error: ('HY000', '[HY000] [Microsoft][ODBC Excel Driver] Deleting data in a
    # linked table is not supported by this ISAM. (-5410) (SQLExecDirectW)')


def create_data():
    #insert into table_name (col1,col2,...) values (va1,val2,...)
    query = "INSERT INTO [EMPLOYEES$] (S_NO,NAME,AGE,SALARY,COUNTRY) VALUES ('5','VIRAT','35','100K','INDIA')"
    cursor.execute(query)
    cursor.commit()
    print("new record created.")



retrieve_data()
# update_data()
# delete_record()
# create_data()


cursor.close()
conn.close()



