import time

from Day2 import demo_operators as do

# do.arithemetic()

# import code

# code.code()

s= "abc"
print(type(s))
s.lower()