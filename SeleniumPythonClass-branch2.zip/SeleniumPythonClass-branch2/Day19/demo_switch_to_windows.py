import time

from selenium import webdriver
from selenium.webdriver.common.by import By


class WindowHandle:
    def testcase(self):
        driver = webdriver.Chrome()
        website_url = "https://demo.automationtesting.in/Windows.html"
        driver.get(website_url)
        time.sleep(5)
        driver.maximize_window()

        btn_xpath = "//a//button[@class='btn btn-info']"
        web_element = driver.find_element(By.XPATH,btn_xpath)
        web_element.click()

        ## New window will appear
        ## Driver focus should be on the new window

        list_of_windows = driver.window_handles   #0,1
        driver.switch_to.window(list_of_windows[1])

        time.sleep(5)


        link_xpath = "//a/span[text()='Documentation']"
        doc_webelement = driver.find_element(By.XPATH,link_xpath)
        doc_webelement.click()

        time.sleep(5)

        driver.close()      #closing the new window
        time.sleep(2)

        driver.switch_to.window(list_of_windows[0])     #focus back to homw window

        web_element.click()     #clicking the button in home window

        time.sleep(5)




obj = WindowHandle()
obj.testcase()


##
'''
Navigate to https://demo.automationtesting.in/Windows.html
Click on this Separate Windows section
click the button
Shift focus to new tab/window and click on Projects & Support buttons
close the child window
Focus back to home window
and click on any elemen on home page
'''