from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains as AC
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import datetime
from selenium.common.exceptions import NoSuchElementException,TimeoutException

from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.maximize_window()

driver.get("https://www.flipkart.com/")

wait = WebDriverWait(driver,5,poll_frequency=2.5,ignored_exceptions=[Exception])

ac_obj = AC(driver)

start_time = datetime.datetime.now()
ele1 = wait.until(EC.element_to_be_clickable((By.XPATH,"//a[@aria-label='Mobiles']")))
end_time = datetime.datetime.now()
ac_obj.move_to_element(ele1).click().perform()
print(start_time,end_time,end_time-start_time)

time.sleep(5)
driver.quit()

#2025-06-09 21:14:05.961917 2025-06-09 21:14:06.134782 0:00:00.172865
#2025-06-09 21:15:18.593462 2025-06-09 21:15:18.992140 0:00:00.398678