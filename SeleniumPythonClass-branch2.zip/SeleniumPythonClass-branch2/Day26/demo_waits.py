from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains as AC

from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.maximize_window()

driver.get("https://www.flipkart.com/")

ac_obj = AC(driver)

driver.implicitly_wait(10)          #implicit
# time.sleep(5)
ele = driver.find_element(By.XPATH,"//a[@aria-label='Mobiles']")
ac_obj.move_to_element(ele).click().perform()

driver.find_element(By.XPATH,"//a[text()='Flights']").click()
# time.sleep(3)
# driver.find_element(By.XPATH,"//a[text()='Login']").click()
ele2 = driver.find_element(By.XPATH,"//input[@id='ROUND_TRIP']")
# ele.click()
print(ele2.is_enabled())
ac_obj.move_to_element(ele2).click().perform()


print("****************")
time.sleep(5)
driver.quit()

