from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains as AC
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from Day28 import demo_excel

from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.maximize_window()

driver.get("https://www.flipkart.com/")

wait = WebDriverWait(driver,5)

ac_obj = AC(driver)

xpath1 = demo_excel.data_sheet.cell(5,5).value
print(xpath1)
# ele1 = wait.until(EC.element_to_be_clickable((By.XPATH,"//a[@aria-label='Mobiles']")))
ele1 = wait.until(EC.element_to_be_clickable((By.XPATH,xpath1)))
ac_obj.move_to_element(ele1).click().perform()
# driver.find_element(By.XPATH,"//a[@aria-label='Mobiles']").click()

driver.find_element(By.XPATH,"//a[text()='Flights']").click()

ele = wait.until(EC.presence_of_element_located((By.XPATH,"//input[@id='ROUND_TRIP']")))
ac_obj.move_to_element(ele).click().perform()


print("****************")
time.sleep(5)
driver.quit()

