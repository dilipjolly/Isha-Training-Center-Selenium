from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select


driver = webdriver.Chrome()
driver.maximize_window()

CalendarURL = "https://demo.automationtesting.in/Datepicker.html"
driver.get(url=CalendarURL)

Date2_ID = "datepicker2"
# driver.find_element(By.ID,Date2_ID).click()
driver.find_element(By.ID,Date2_ID).send_keys("05/01/1975")
time.sleep(5)
exit()
time.sleep(2)
#Year Selection
year_xpath = "//select[@title='Change the year']"
year_webElement = driver.find_element(By.XPATH,year_xpath)
select_obj = Select(year_webElement)
try:
    select_obj.select_by_visible_text("2000")
    print("In Try block")
except:
    select_obj.select_by_index(0)
    year_webElement = driver.find_element(By.XPATH, year_xpath)
    select_obj = Select(year_webElement)
    select_obj.select_by_visible_text("2000")
    print("In Exception block")
time.sleep(2)

#Month Selection
month_xpath = "//select[@title='Change the month']"
month_webElement = driver.find_element(By.XPATH,month_xpath)
select_obj1 = Select(month_webElement)
select_obj1.select_by_visible_text("January")
time.sleep(2)
#Date Selection
Date_XPATH = "//a[text()='31']"
driver.find_element(By.XPATH,Date_XPATH).click()

time.sleep(5)


