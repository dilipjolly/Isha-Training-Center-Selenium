import time
from Screenshot import Screenshot
from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Chrome()
driver.get("https://demo.automationtesting.in/Register.html")
driver.maximize_window()
time.sleep(2)

def visible_part_screenshot():
    driver.save_screenshot(r"D:\Isha\SeleniumPythonClass\Screenshots\image_before.png")

    #Filling the fields
    driver.find_element(By.XPATH,"//input[@placeholder='First Name']").send_keys("Ishaaaa")

    time.sleep(0.25)

    driver.save_screenshot(r"D:\Isha\SeleniumPythonClass\Screenshots\image_after.png")

    time.sleep(5)

    driver.quit()


def element_screenshot():

    web_element = driver.find_element(By.XPATH, "//input[@placeholder='First Name']")
    web_element.screenshot(r"D:\Isha\SeleniumPythonClass\Screenshots\ele_before.png")
    # Filling the fields
    web_element.send_keys("Ishaaaa")
    web_element.screenshot(r"D:\Isha\SeleniumPythonClass\Screenshots\ele_after.png")

    time.sleep(5)
    driver.quit()


def full_page_screenshot():
    # fp_obj = Screenshot.Screenshot()
    # fp_obj.full_screenshot(driver,"D:\Isha\SeleniumPythonClass\Screenshots","fp_image.png")
    fp_obj = Screenshot(driver)
    fp_obj.capture_full_page(r"D:\Isha\SeleniumPythonClass\Screenshots\fp_image1.png")

    time.sleep(2)
    driver.quit()


# element_screenshot()
full_page_screenshot()