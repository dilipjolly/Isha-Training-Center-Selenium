l = input("Give some values").split(" ")
s = input("Give some values")
print(l)
t = tuple(l)
print(t)
exit()


t = "Hi",
t2 = (2,)
print(type(t),type(t2))
t3 = (2,4,6,8,6,6)
print(t3[2])
print(t3.index(8))
print(t3.count(6))
l = list(t3)
print(l,type(l))
print(tuple(l))

#a=9
t = 9,
x= (1,2,3)
y= (2,4,6)

#sets & dictionaries
