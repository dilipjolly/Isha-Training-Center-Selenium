import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains as AC


driver = webdriver.Chrome()
driver.maximize_window()

driver.get(r"D:/Isha/SeleniumPythonClass/StaticWebPage/site-2/index.html")
time.sleep(2.5)

table_element = driver.find_element(By.XPATH,"//h2[text()='Links']")
AC(driver).scroll_to_element(table_element).perform()

# time.sleep(2.5)

Name = "Abdul"
checkbox_xpath = "//td[text()='"+Name+"']/preceding-sibling::td/input"

print(checkbox_xpath)
driver.find_element(By.XPATH,checkbox_xpath).click()

inputfield_xpath = "//td[text()='"+Name+"']/following-sibling::td[4]/input"
print(inputfield_xpath)
driver.find_element(By.XPATH,inputfield_xpath).send_keys("Abdullllll")

time.sleep(5)
driver.quit()



full_string = "//td[text()='Abdul']/preceding-sibling::td/input"
s1 = "//td[text()='"
s2 = "Abdul"
s3 = "']/preceding-sibling::td/input"

s = "//td[text()='"+s2+"']/preceding-sibling::td/input"



