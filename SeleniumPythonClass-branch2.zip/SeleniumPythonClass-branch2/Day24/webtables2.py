import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains as AC


driver = webdriver.Chrome()
driver.maximize_window()

driver.get(r"D:/Isha/SeleniumPythonClass/StaticWebPage/site-1/index.html")
time.sleep(2.5)

table_element = driver.find_element(By.XPATH,"//h2[text()='Image']")
AC(driver).scroll_to_element(table_element).perform()

time.sleep(2.5)



##Acess specific cell

rows_xpath = "//table//tr"
columns_xpath = "//table//tr[1]/th"

row_elements = driver.find_elements(By.XPATH,rows_xpath)
print(row_elements)
rows = len(row_elements)
columns = len(driver.find_elements(By.XPATH,columns_xpath))

var1 = 6
var2 = 1
xpath = "//table//tr["+str(var1)+"]/td["+str(var2)+"]"

target_value = "Dhoni"
for row in range(2,rows+1):     #(2,7)  2,3,4,5,6
    for column in range(1,columns+1):
        dynamic_cell_xpath = "//table//tr[" + str(row) + "]//td[" + str(column) + "]"
        # print(dynamic_cell_xpath)
        value = driver.find_element(By.XPATH,dynamic_cell_xpath).text
        if value == target_value:
            print(value)
            break