import time
import pytest
import logging
obj = logging.getLogger()
obj.setLevel(logging.INFO)

@pytest.mark.regression
def test_subtract():
    res= 5-10
    exp =-10
    if res == exp:
        # obj.info("This case passed.")
        logging.info("This case passed.")
    else:
        obj.error("This case failed.")
        assert False


@pytest.mark.regression
def test_add():
    print(5+10)
    # time.sleep(2)
    assert True

@pytest.mark.sanity
@pytest.mark.regression
def test_add1():
    print(5+10)
    # time.sleep(2)
    assert True

@pytest.mark.smoke
def test_multiply():
    print(10*5)

