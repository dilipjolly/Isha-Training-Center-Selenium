import pytest
import pytest_html,pytest_html.extras


def pytest_html_report_title(report):
    report.title = "Test Suite Report"


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    extras = getattr(report, "extras", [])
    if report.when == "call":
        # always add url to report

        xfail = hasattr(report, "wasxfail")
        # if (report.skipped and xfail) or (report.failed and not xfail):
            # only add additional html on failure
            # extras.append(pytest_html.extras.html("<div>Additional HTML</div>"))
        extras.append(pytest_html.extras.url("https://demo.automationtesting.in/Register.html"))
        extras.append(pytest_html.extras.png("D:\Isha\SeleniumPythonClass\Screenshots\ele_after.png"))
        report.extras = extras