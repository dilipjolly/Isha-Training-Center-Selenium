#print('Hello World')
# print("Welcome All")

# variables

var = 1
var2 = 3.3
a = True
b = False
c= "Isha"


#10 to 4 variables

# m=10
# n=20
# o=30
# p=40

# m = n= o = p = 10

m,n,o,p = 10,20,30,40
print(o)



print(m,n,o,p)

# print(var,var2,a,b)
# print(b)

# for i in range(1,11):#,1,2,...9,10
#     print(i,c)

# print(c)
# print(c)
# print(c)
# print(c)


def add():
    for i in range(0,11,3):#0,1,2,...9,10  #0,2,4,6,8  #0,3,6,9
        print(i,c)
    # c= x+y
    # print(c)

add()


# add(10,100)
# add(100,500)

