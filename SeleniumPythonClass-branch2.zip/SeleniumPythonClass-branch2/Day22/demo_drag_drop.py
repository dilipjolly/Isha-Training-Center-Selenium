from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains as AC
from selenium.webdriver.common.keys import Keys

import time

driver = webdriver.Chrome()

driver.get("https://demo.automationtesting.in/Static.html")
driver.maximize_window()
time.sleep(2.5)
#scrolling to fb link which is at bottom of the page

element = driver.find_element(By.XPATH,"//a[@class='link facebook']")
AC(driver).scroll_to_element(element).perform()
time.sleep(5)

exit()
drop_area_element = driver.find_element(By.ID,"droparea")
src_element = driver.find_element(By.XPATH,"//img[contains(@src,'logo.png')]")
src1_element = driver.find_element(By.XPATH,"//img[contains(@id,'mongo')]")
src2_element = driver.find_element(By.XPATH,"//img[contains(@src,'selenium.png')]")


obj = AC(driver)
obj.drag_and_drop(src_element,drop_area_element).perform()
time.sleep(2)
obj.drag_and_drop(src2_element,drop_area_element).perform()
time.sleep(2)
obj.drag_and_drop(src1_element,drop_area_element).perform()

time.sleep(5)