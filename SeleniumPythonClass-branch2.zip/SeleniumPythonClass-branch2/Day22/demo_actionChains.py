from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains as AC
from selenium.webdriver.common.keys import Keys

import time

driver = webdriver.Chrome()

driver.get("https://demo.automationtesting.in/Register.html")
driver.maximize_window()
time.sleep(2.5)


#Task 1
#Do Mouse hover on Widgets element & then click on this AutoComplete
def task1(driver):
    widgets_xpath = "//a[text()='Widgets']"
    widget_element = driver.find_element(By.XPATH, widgets_xpath)

    ##
    action_obj = AC(driver)
    action_obj.move_to_element(widget_element).perform()
    time.sleep(5)

    dp_xpath = "//a[text()=' Datepicker ']"
    element = driver.find_element(By.XPATH, dp_xpath)
    element.click()

    time.sleep(5)


#Task2
# press special key - CONTROL then send key A release CONTROL key
def task2(driver):
    action_obj = AC(driver)
    action_obj.key_down(Keys.CONTROL).send_keys("A").key_up(Keys.CONTROL).perform()

    time.sleep(5)

    action_obj.send_keys(Keys.PAGE_DOWN).perform()

    time.sleep(5)

# task1(driver)