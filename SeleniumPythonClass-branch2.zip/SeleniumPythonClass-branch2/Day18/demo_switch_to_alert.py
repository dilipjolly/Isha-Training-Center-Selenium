import time

from selenium import webdriver
from selenium.webdriver.common.by import By



driver = webdriver.Chrome()
driver.maximize_window()

url = "https://demo.automationtesting.in/Alerts.html"
driver.get(url)

time.sleep(2.5)

###Task-1
# alert_xpath = "//button[@class ='btn btn-danger']"
# alert_obj = driver.find_element(By.XPATH,alert_xpath)
# alert_obj.click()
#
# time.sleep(5)
#
# #accept the alert
# driver.switch_to.alert.accept()
#
# time.sleep(5)

###Task-2
#clicking the section named- Alert with OK & Cancel
driver.find_element(By.PARTIAL_LINK_TEXT,"Alert with OK & Cancel").click()

time.sleep(2)

alert_xpath = "//button[@class ='btn btn-primary']"
alert_obj = driver.find_element(By.XPATH,alert_xpath)
alert_obj.click()

time.sleep(2)

driver.switch_to.alert.dismiss()

time.sleep(5)

