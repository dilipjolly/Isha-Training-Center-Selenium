import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select



driver = webdriver.Chrome()
driver.maximize_window()

url = "D:/Isha/SeleniumPythonClass/StaticWebPage/site-1/index.html"
driver.get(url)

time.sleep(3)
#######
# malexpath = "//input[@value='male']"
# obj = driver.find_element(By.XPATH,malexpath)
# obj.click()
#############
dropdown_xpath = "//select[@id='fruit']"
dropdown_element = driver.find_element(By.XPATH,dropdown_xpath)

select_obj = Select(dropdown_element)
#way-1
select_obj.select_by_visible_text("Banana")
time.sleep(5)
#way-2
select_obj.select_by_index(5)
#way-3
time.sleep(5)
select_obj.select_by_value("banana")

time.sleep(5)

