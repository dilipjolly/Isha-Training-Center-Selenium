import time
import pytest

@pytest.mark.regression
def test_subtract():
    print(5-10)
    # time.sleep(2)
    assert True

@pytest.mark.regression
def test_add():
    print(5+10)
    # time.sleep(2)
    assert True

@pytest.mark.sanity
@pytest.mark.regression
def test_add1():
    print(5+10)
    # time.sleep(2)
    assert True

@pytest.mark.smoke
def test_multiply():
    print(10*5)

