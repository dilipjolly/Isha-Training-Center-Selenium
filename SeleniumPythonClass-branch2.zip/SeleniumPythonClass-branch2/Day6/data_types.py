str = "Hello WORLD"
print(str[1:])
exit()
str2 = 'Hello World'
para = "Hi Guys, a very good evening. Hi again"

a= "Sachinii"
print(a.count("Hi"))
a = " Sehwag is a batter"
print(a)
print(a.strip())

exit()

list_of_words = para.split(" ")
print(list_of_words)
print(type(list_of_words))
# l = len(list_of_words)
print("No:of words in paragraph:",len(list_of_words))
print("No:of words in paragraph: {}".format(len(list_of_words)))

exit()
print(len(str))     # returns no:of characters
print(str.lower())
print(str.upper())

print(str.find("lloo"))
print(str.find("W"))

print(str.replace("Hello","Hi"))
var = str.replace("Hello","Hi")
print(var.lower())







