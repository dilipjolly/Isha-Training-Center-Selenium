import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains as AC

driver = webdriver.Chrome()
url = "https://www.abhibus.com/"
driver.get(url)
driver.maximize_window()
driver.implicitly_wait(5)

action_obj = AC(driver)


leaving_obj = driver.find_element(value="//input[@placeholder='Leaving From']",by= By.XPATH)
leaving_obj.send_keys("Bangalore")
time.sleep(5)
###     way1    ###
# leaving_obj.send_keys(Keys.ENTER)       #select 1st auto-suggestion
###     way2    ###
auto_sugg_xpath = "//div[text()='Mangalore']"
auto_ele = driver.find_element(By.XPATH,auto_sugg_xpath)
action_obj.move_to_element(auto_ele).click().perform()

time.sleep(5)
