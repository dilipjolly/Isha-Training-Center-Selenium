import openpyxl

fp = "D:\Isha\SeleniumPythonClass\ExternalFiles\DataSheet.xlsx"
wb_obj = openpyxl.load_workbook(fp)

emp_sheet = wb_obj['Employees']


rows = emp_sheet.max_row
print(rows)

columns = emp_sheet.max_column
print(columns)

# getting data from cell row =2, col=2
name = emp_sheet.cell(2,2).value
print(name)

## updating data to this cell row =3, col=5
# emp_sheet.cell(3,5).value = "CANADA"
# print("Updated")
# wb_obj.save(fp)

#Task-1: get all emp names
for row in range(2,rows+1):
    name = emp_sheet.cell(row,2).value
    print("Employee name: {}".format(name))




## Data
data_sheet = wb_obj['Data']

